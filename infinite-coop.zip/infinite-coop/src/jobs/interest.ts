/**
 * Daily/monthly interest job.
 *   tsx src/jobs/interest.ts accrue   -> record today's accrual for every wallet (chunked cursor)
 *   tsx src/jobs/interest.ts credit   -> credit accrued interest as ledger entries (run month-end)
 * Processes members in chunks of 500 to keep memory flat.
 */
import { db } from "../lib/db";
import { dailyAccrualMicroKobo, microToKobo } from "../lib/interest";
import { ACCOUNTS, memberAccountCode, postEntry } from "../lib/ledger";

const CHUNK = 500;

async function currentPolicy(at: Date) {
  return db.interestPolicy.findFirst({ where: { effectiveFrom: { lte: at } }, orderBy: { effectiveFrom: "desc" } });
}

export async function accrue(date = new Date()) {
  const day = new Date(Date.UTC(date.getUTCFullYear(), date.getUTCMonth(), date.getUTCDate()));
  const policy = await currentPolicy(day);
  if (!policy) return console.log("No interest policy in effect; nothing accrued.");

  let cursor: string | undefined;
  let count = 0;
  for (;;) {
    const wallets = await db.wallet.findMany({
      take: CHUNK,
      ...(cursor ? { skip: 1, cursor: { id: cursor } } : {}),
      orderBy: { id: "asc" },
      select: { id: true, memberId: true, balanceKobo: true },
    });
    if (wallets.length === 0) break;
    cursor = wallets[wallets.length - 1].id;

    const data = wallets
      .filter((w) => w.balanceKobo >= policy.minBalanceKobo && w.balanceKobo > 0n)
      .map((w) => ({
        memberId: w.memberId,
        accrualDate: day,
        balanceKobo: w.balanceKobo,
        accruedMicroKobo: dailyAccrualMicroKobo(w.balanceKobo, policy.annualRateBps, policy.dayCount),
      }));
    if (data.length) await db.interestAccrual.createMany({ data, skipDuplicates: true });
    count += data.length;
  }
  console.log(`Accrued interest for ${count} wallets on ${day.toISOString().slice(0, 10)}`);
}

export async function credit() {
  const members = await db.interestAccrual.groupBy({ by: ["memberId"], where: { creditedEntryId: null } });
  let credited = 0;
  for (let i = 0; i < members.length; i += CHUNK) {
    for (const { memberId } of members.slice(i, i + CHUNK)) {
      await db.$transaction(async (tx) => {
        const rows = await tx.interestAccrual.findMany({ where: { memberId, creditedEntryId: null } });
        const micro = rows.reduce((a, r) => a + r.accruedMicroKobo, 0n);
        const kobo = microToKobo(micro);
        if (kobo <= 0n) return;
        const key = `interest:${memberId}:${rows[0].id}:${rows.length}`;
        const entry = await postEntry(tx, {
          idempotencyKey: key,
          reference: `INT-${memberId}-${Date.now()}`,
          txType: "INTEREST_CREDIT",
          description: "Savings interest credit",
          lines: [
            { accountCode: ACCOUNTS.INTEREST_EXPENSE, debit: kobo },
            { accountCode: memberAccountCode(memberId), credit: kobo },
          ],
        });
        await tx.interestAccrual.updateMany({ where: { id: { in: rows.map((r) => r.id) } }, data: { creditedEntryId: entry.id } });
        await tx.transaction.create({
          data: { memberId, type: "INTEREST_CREDIT", status: "POSTED", amountKobo: kobo, reference: entry.reference, narration: "Interest credit", entryId: entry.id, settledAt: new Date() },
        });
        await tx.wallet.update({ where: { memberId }, data: { balanceKobo: { increment: kobo }, interestEarnedKobo: { increment: kobo }, version: { increment: 1 } } });
        credited++;
      });
    }
  }
  console.log(`Credited interest to ${credited} members`);
}

if (require.main === module) {
  const mode = process.argv[2];
  (mode === "credit" ? credit() : accrue()).finally(() => db.$disconnect());
}

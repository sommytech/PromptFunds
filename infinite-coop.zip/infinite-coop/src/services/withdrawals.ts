import { db } from "@/lib/db";
import { audit } from "@/lib/audit";
import { HttpError } from "@/lib/auth";
import { ACCOUNTS, memberAccountCode, postEntry } from "@/lib/ledger";
import { getPaymentProvider } from "@/lib/providers/payments";

const DUAL_APPROVAL_THRESHOLD_KOBO = 50_000_000n; // ₦500,000 — make configurable via Setting

/** Member requests withdrawal. Row-locks the wallet so parallel requests cannot overdraw. */
export async function requestWithdrawal(memberId: string, amountKobo: bigint, idempotencyKey: string) {
  if (amountKobo <= 0n) throw new HttpError(422, "Amount must be positive");

  return db.$transaction(async (tx) => {
    const dup = await tx.withdrawal.findUnique({ where: { idempotencyKey } });
    if (dup) return dup;

    const bank = await tx.bankAccount.findUnique({ where: { memberId } });
    if (!bank || !bank.nameMatched) throw new HttpError(422, "Verified bank account required");

    // Pessimistic lock on the wallet row
    const rows = await tx.$queryRaw<{ balanceKobo: bigint; heldKobo: bigint }[]>`
      SELECT "balanceKobo", "heldKobo" FROM "Wallet" WHERE "memberId" = ${memberId} FOR UPDATE`;
    const w = rows[0];
    if (!w) throw new HttpError(404, "Wallet not found");
    const available = w.balanceKobo - w.heldKobo;
    if (amountKobo > available) throw new HttpError(422, "Insufficient available balance");

    await tx.wallet.update({ where: { memberId }, data: { heldKobo: { increment: amountKobo }, version: { increment: 1 } } });
    const wd = await tx.withdrawal.create({ data: { memberId, amountKobo, idempotencyKey, makerId: memberId } });
    await tx.transaction.create({
      data: { memberId, type: "WITHDRAWAL", status: "PENDING", amountKobo, reference: `WD-${wd.id}`, narration: "Withdrawal request" },
    });
    await audit({ actorId: memberId, action: "WITHDRAWAL_REQUESTED", entityType: "Withdrawal", entityId: wd.id, after: { amountKobo } }, tx);
    return wd;
  });
}

/** Staff approval (checker). Must differ from any prior approver; large amounts need an approver role. */
export async function approveWithdrawal(withdrawalId: string, approverId: string, approverRole: string) {
  const wd = await db.withdrawal.findUniqueOrThrow({ where: { id: withdrawalId }, include: { member: { include: { bankAccount: true } } } });
  if (wd.status !== "PENDING_APPROVAL") throw new HttpError(409, "Withdrawal not pending");
  if (wd.makerId === approverId) throw new HttpError(403, "Maker cannot approve own request");
  if (wd.amountKobo >= DUAL_APPROVAL_THRESHOLD_KOBO && approverRole !== "FINANCE_APPROVER" && approverRole !== "ADMIN")
    throw new HttpError(403, "Finance approver required for this amount");

  const bank = wd.member.bankAccount;
  if (!bank || !bank.nameMatched) throw new HttpError(422, "Payout account not verified");

  await db.withdrawal.update({ where: { id: wd.id }, data: { status: "PROCESSING", checkerId: approverId, approvedAt: new Date() } });

  const result = await getPaymentProvider().payout({
    reference: wd.id,
    amountKobo: wd.amountKobo,
    bankCode: bank.bankCode,
    accountNumber: bank.accountNumber,
    accountName: bank.accountName,
  });

  if (result.status === "FAILED") {
    await db.$transaction(async (tx) => {
      await tx.withdrawal.update({ where: { id: wd.id }, data: { status: "FAILED", failureReason: result.reason } });
      await tx.wallet.update({ where: { memberId: wd.memberId }, data: { heldKobo: { decrement: wd.amountKobo } } });
      await tx.transaction.update({ where: { reference: `WD-${wd.id}` }, data: { status: "FAILED" } });
      await audit({ actorId: approverId, action: "WITHDRAWAL_PAYOUT_FAILED", entityType: "Withdrawal", entityId: wd.id }, tx);
    });
    throw new HttpError(502, "Payout failed; funds released");
  }

  if (result.status === "PAID") return markPaid(wd.id, wd.memberId, wd.amountKobo, result.providerRef, approverId);
  await db.withdrawal.update({ where: { id: wd.id }, data: { payoutRef: result.providerRef } });
  return db.withdrawal.findUniqueOrThrow({ where: { id: wd.id } });
}

export async function markPaid(withdrawalId: string, memberId: string, amountKobo: bigint, providerRef: string, actorId?: string) {
  return db.$transaction(async (tx) => {
    const entry = await postEntry(tx, {
      idempotencyKey: `withdrawal:${withdrawalId}`,
      reference: `WD-${withdrawalId}`,
      txType: "WITHDRAWAL",
      description: "Withdrawal paid to member bank account",
      lines: [
        { accountCode: memberAccountCode(memberId), debit: amountKobo },
        { accountCode: ACCOUNTS.BANK_PAYOUTS, credit: amountKobo },
      ],
      createdBy: actorId,
    });
    await tx.wallet.update({
      where: { memberId },
      data: {
        balanceKobo: { decrement: amountKobo },
        heldKobo: { decrement: amountKobo },
        totalWithdrawalsKobo: { increment: amountKobo },
        version: { increment: 1 },
      },
    });
    await tx.transaction.update({ where: { reference: `WD-${withdrawalId}` }, data: { status: "POSTED", entryId: entry.id, settledAt: new Date() } });
    const wd = await tx.withdrawal.update({ where: { id: withdrawalId }, data: { status: "PAID", paidAt: new Date(), payoutRef: providerRef } });
    await audit({ actorId, action: "WITHDRAWAL_PAID", entityType: "Withdrawal", entityId: withdrawalId, after: { amountKobo } }, tx);
    return wd;
  });
}

export async function rejectWithdrawal(withdrawalId: string, actorId: string, reason: string) {
  return db.$transaction(async (tx) => {
    const wd = await tx.withdrawal.findUniqueOrThrow({ where: { id: withdrawalId } });
    if (wd.status !== "PENDING_APPROVAL") throw new HttpError(409, "Withdrawal not pending");
    await tx.wallet.update({ where: { memberId: wd.memberId }, data: { heldKobo: { decrement: wd.amountKobo } } });
    await tx.transaction.update({ where: { reference: `WD-${wd.id}` }, data: { status: "FAILED" } });
    await audit({ actorId, action: "WITHDRAWAL_REJECTED", entityType: "Withdrawal", entityId: wd.id, after: { reason } }, tx);
    return tx.withdrawal.update({ where: { id: wd.id }, data: { status: "REJECTED", failureReason: reason, checkerId: actorId } });
  });
}

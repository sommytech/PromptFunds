import { db } from "@/lib/db";
import { hashPassword } from "@/lib/auth";
import { audit } from "@/lib/audit";
import { memberAccountCode } from "@/lib/ledger";
import { getPaymentProvider } from "@/lib/providers/payments";

export async function registerMember(input: { email: string; phone: string; password: string; firstName: string; lastName: string }) {
  const passwordHash = await hashPassword(input.password);
  return db.$transaction(async (tx) => {
    const user = await tx.user.create({
      data: { email: input.email.toLowerCase(), phone: input.phone, passwordHash, role: "MEMBER", status: "PENDING" },
    });
    const member = await tx.member.create({
      data: {
        userId: user.id,
        firstName: input.firstName,
        lastName: input.lastName,
        searchText: `${input.firstName} ${input.lastName} ${input.phone} ${input.email}`.toLowerCase(),
      },
    });
    await audit({ actorId: user.id, action: "MEMBER_REGISTERED", entityType: "Member", entityId: member.id }, tx);
    return { user, member };
  });
}

/** Approve KYC: issue unique membership number, create ledger account + wallet + virtual account. */
export async function approveKyc(memberId: string, officerId: string) {
  const member = await db.member.findUniqueOrThrow({ where: { id: memberId }, include: { user: true } });
  if (member.kycStatus === "APPROVED") return member;

  const va = await getPaymentProvider().createVirtualAccount(memberId, `${member.firstName} ${member.lastName}`);
  const year = new Date().getFullYear();

  return db.$transaction(async (tx) => {
    const counter = await tx.membershipCounter.upsert({
      where: { year },
      create: { year, value: 1 },
      update: { value: { increment: 1 } },
    });
    const membershipNumber = `IC-${year}-${String(counter.value).padStart(6, "0")}`;

    const acct = await tx.ledgerAccount.create({
      data: { code: memberAccountCode(memberId), name: `Member savings ${membershipNumber}`, type: "LIABILITY", memberId },
    });
    await tx.wallet.create({ data: { memberId, ledgerAccountId: acct.id } });
    await tx.virtualAccount.create({ data: { memberId, provider: process.env.PAYMENT_PROVIDER ?? "mock", ...va } });
    await tx.user.update({ where: { id: member.userId }, data: { status: "ACTIVE" } });
    const updated = await tx.member.update({
      where: { id: memberId },
      data: {
        membershipNumber,
        kycStatus: "APPROVED",
        kycReviewedBy: officerId,
        kycReviewedAt: new Date(),
        searchText: `${member.searchText} ${membershipNumber.toLowerCase()}`,
      },
    });
    await audit({ actorId: officerId, action: "KYC_APPROVED", entityType: "Member", entityId: memberId, after: { membershipNumber } }, tx);
    return updated;
  });
}

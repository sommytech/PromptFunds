import type { Metadata, Viewport } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: { default: "Infinite Cooperative — Save, grow, borrow", template: "%s | Infinite Cooperative" },
  description: "Free-to-join cooperative savings and loans. Register online, deposit, earn interest and apply for loans from your phone.",
};
export const viewport: Viewport = { width: "device-width", initialScale: 1, themeColor: "#0f5c3a" };

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}

"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";

export default function Login() {
  const router = useRouter();
  const [error, setError] = useState("");

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setError("");
    const body = Object.fromEntries(new FormData(e.currentTarget));
    const res = await fetch("/api/auth/login", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(body) });
    if (res.ok) {
      const { role } = await res.json();
      router.push(role === "MEMBER" ? "/dashboard" : "/admin");
    } else setError((await res.json()).title ?? "Login failed");
  }

  const input = "w-full rounded-xl border border-slate-300 px-4 py-3 min-h-[48px]";
  return (
    <main className="mx-auto max-w-md px-4 py-10">
      <h1 className="text-2xl font-bold text-brand-dark">Log in</h1>
      <form onSubmit={onSubmit} className="card mt-6 space-y-4">
        <input name="email" type="email" placeholder="Email" required className={input} autoComplete="email" />
        <input name="password" type="password" placeholder="Password" required className={input} autoComplete="current-password" />
        {error && <p role="alert" className="text-red-700">{error}</p>}
        <button className="btn btn-primary w-full">Log in</button>
      </form>
    </main>
  );
}

"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";

export default function Register() {
  const router = useRouter();
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setBusy(true);
    setError("");
    const body = Object.fromEntries(new FormData(e.currentTarget));
    const res = await fetch("/api/auth/register", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(body) });
    setBusy(false);
    if (res.ok) router.push("/dashboard");
    else setError((await res.json()).title ?? "Registration failed");
  }

  const input = "w-full rounded-xl border border-slate-300 px-4 py-3 min-h-[48px]";
  return (
    <main className="mx-auto max-w-md px-4 py-10">
      <h1 className="text-2xl font-bold text-brand-dark">Join free</h1>
      <p className="mt-1 text-slate-600">No fee. No minimum deposit.</p>
      <form onSubmit={onSubmit} className="card mt-6 space-y-4">
        <input name="firstName" placeholder="First name" required className={input} autoComplete="given-name" />
        <input name="lastName" placeholder="Last name" required className={input} autoComplete="family-name" />
        <input name="email" type="email" placeholder="Email" required className={input} autoComplete="email" />
        <input name="phone" type="tel" placeholder="Phone (e.g. 2348012345678)" required className={input} autoComplete="tel" />
        <input name="password" type="password" placeholder="Password (10+ characters)" minLength={10} required className={input} autoComplete="new-password" />
        {error && <p role="alert" className="text-red-700">{error}</p>}
        <button disabled={busy} className="btn btn-primary w-full">{busy ? "Creating…" : "Create account"}</button>
      </form>
    </main>
  );
}

import { redirect } from "next/navigation";
import { currentUser } from "@/lib/auth";
import { db } from "@/lib/db";
import { formatNaira } from "@/lib/money";

export const dynamic = "force-dynamic";

export default async function Dashboard() {
  const user = await currentUser();
  if (!user) redirect("/login");
  const member = user.member;
  if (!member) redirect("/admin");

  if (member.kycStatus !== "APPROVED") {
    return (
      <main className="mx-auto max-w-md px-4 py-10">
        <div className="card">
          <h1 className="text-xl font-bold text-brand-dark">Verification in progress</h1>
          <p className="mt-2 text-slate-600">Your identity check is {member.kycStatus.toLowerCase().replace("_", " ")}. You will get your membership number and wallet as soon as you are approved.</p>
        </div>
      </main>
    );
  }

  const [wallet, recent, va] = await Promise.all([
    db.wallet.findUniqueOrThrow({ where: { memberId: member.id } }),
    db.transaction.findMany({ where: { memberId: member.id }, orderBy: { createdAt: "desc" }, take: 5 }),
    db.virtualAccount.findUnique({ where: { memberId: member.id } }),
  ]);

  return (
    <main className="mx-auto max-w-2xl space-y-4 px-4 py-8">
      <p className="text-sm text-slate-500">Member {member.membershipNumber}</p>
      <section className="card bg-brand text-white">
        <p className="text-sm opacity-80">Total savings</p>
        <p className="text-4xl font-extrabold">{formatNaira(wallet.balanceKobo)}</p>
        <div className="mt-4 grid grid-cols-3 gap-2 text-sm">
          <div><p className="opacity-70">Available</p><p className="font-semibold">{formatNaira(wallet.balanceKobo - wallet.heldKobo)}</p></div>
          <div><p className="opacity-70">Interest</p><p className="font-semibold">{formatNaira(wallet.interestEarnedKobo)}</p></div>
          <div><p className="opacity-70">Pending</p><p className="font-semibold">{formatNaira(wallet.heldKobo)}</p></div>
        </div>
      </section>

      {va && (
        <section className="card">
          <h2 className="font-semibold text-brand">Deposit by bank transfer</h2>
          <p className="mt-1 text-slate-600">{va.bankName} · <span className="font-mono">{va.accountNumber}</span></p>
          <p className="text-sm text-slate-500">{va.accountName}</p>
        </section>
      )}

      <section className="card">
        <h2 className="font-semibold text-brand">Recent activity</h2>
        <ul className="mt-2 divide-y">
          {recent.length === 0 && <li className="py-3 text-slate-500">No transactions yet.</li>}
          {recent.map((t) => (
            <li key={t.id} className="flex justify-between py-3">
              <span>{t.type.replace("_", " ").toLowerCase()} <em className="text-xs text-slate-400">{t.status.toLowerCase()}</em></span>
              <span className="font-semibold">{formatNaira(t.amountKobo)}</span>
            </li>
          ))}
        </ul>
      </section>
    </main>
  );
}

import Link from "next/link";

const benefits = [
  { t: "Free to join", d: "No registration fee, no minimum deposit, no compulsory monthly contribution." },
  { t: "Earn interest", d: "Your savings earn interest under our approved, published savings policy." },
  { t: "Borrow fairly", d: "Apply online for loans with transparent pricing and a clear repayment schedule." },
];

export default function Home() {
  return (
    <main className="mx-auto max-w-5xl px-4 py-10">
      <header className="flex items-center justify-between">
        <span className="text-xl font-bold text-brand">Infinite Cooperative</span>
        <nav className="flex gap-3">
          <Link href="/login" className="btn btn-ghost">Log in</Link>
          <Link href="/register" className="btn btn-primary">Join free</Link>
        </nav>
      </header>

      <section className="py-16">
        <h1 className="text-4xl font-extrabold text-brand-dark sm:text-5xl">Save. Grow. Borrow.</h1>
        <p className="mt-4 max-w-xl text-lg text-slate-600">
          A member-owned cooperative on your phone. Register free, deposit what you can, see your balance update, and apply for a loan without visiting an office.
        </p>
        <Link href="/register" className="btn btn-primary mt-8">Create your free account</Link>
      </section>

      <section className="grid gap-4 sm:grid-cols-3">
        {benefits.map((b) => (
          <div key={b.t} className="card">
            <h2 className="text-lg font-semibold text-brand">{b.t}</h2>
            <p className="mt-2 text-slate-600">{b.d}</p>
          </div>
        ))}
      </section>

      <p className="mt-12 text-sm text-slate-500">
        Infinite Cooperative offers savings and loans to its members only. We do not offer transfers to other people or banks.
      </p>
    </main>
  );
}

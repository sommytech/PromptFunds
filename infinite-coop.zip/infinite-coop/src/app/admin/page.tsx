import { redirect } from "next/navigation";
import { currentUser } from "@/lib/auth";
import { db } from "@/lib/db";
import { formatNaira } from "@/lib/money";
import { trialBalanceVariance } from "@/lib/ledger";

export const dynamic = "force-dynamic";

export default async function Admin() {
  const user = await currentUser();
  if (!user || user.role === "MEMBER") redirect("/login");

  const [kycPending, wdPending, totals, variance] = await Promise.all([
    db.member.count({ where: { kycStatus: { in: ["SUBMITTED", "IN_REVIEW", "NOT_STARTED"] } } }),
    db.withdrawal.aggregate({ where: { status: "PENDING_APPROVAL" }, _count: true, _sum: { amountKobo: true } }),
    db.wallet.aggregate({ _sum: { balanceKobo: true, heldKobo: true } }),
    trialBalanceVariance(),
  ]);

  const stat = (label: string, value: string, warn = false) => (
    <div className={`card ${warn ? "border-red-300" : ""}`}>
      <p className="text-sm text-slate-500">{label}</p>
      <p className="text-2xl font-bold text-brand-dark">{value}</p>
    </div>
  );

  return (
    <main className="mx-auto max-w-5xl px-4 py-8">
      <h1 className="text-2xl font-bold text-brand-dark">Administration</h1>
      <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {stat("KYC queue", String(kycPending))}
        {stat("Withdrawals awaiting approval", `${wdPending._count} · ${formatNaira(wdPending._sum.amountKobo ?? 0n)}`)}
        {stat("Total member savings (liability)", formatNaira(totals._sum.balanceKobo ?? 0n))}
        {stat("Ledger trial balance variance", formatNaira(variance), variance !== 0n)}
      </div>
    </main>
  );
}

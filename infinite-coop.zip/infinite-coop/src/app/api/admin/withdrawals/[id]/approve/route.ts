import { handle, json } from "@/lib/http";
import { requireUser } from "@/lib/auth";
import { approveWithdrawal } from "@/services/withdrawals";

export const POST = handle(async (_req: Request, { params }: { params: { id: string } }) => {
  const u = await requireUser(["FINANCE_OFFICER", "FINANCE_APPROVER", "ADMIN"]);
  const wd = await approveWithdrawal(params.id, u.id, u.role);
  return json(wd);
});

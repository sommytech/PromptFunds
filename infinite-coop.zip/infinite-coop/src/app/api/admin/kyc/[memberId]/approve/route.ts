import { handle, json } from "@/lib/http";
import { requireUser } from "@/lib/auth";
import { approveKyc } from "@/services/members";

export const POST = handle(async (_req: Request, { params }: { params: { memberId: string } }) => {
  const officer = await requireUser(["KYC_OFFICER", "ADMIN"]);
  const m = await approveKyc(params.memberId, officer.id);
  return json({ ok: true, membershipNumber: m.membershipNumber });
});

import { createHmac, timingSafeEqual } from "crypto";

/**
 * Payment partner adapter. Swap the implementation for Paystack/Flutterwave/bank API
 * without touching ledger logic. The cooperative must NOT expose transfers between members
 * or to third parties: payouts go only to the member's verified BankAccount.
 */
export interface PayoutRequest {
  reference: string;
  amountKobo: bigint;
  bankCode: string;
  accountNumber: string;
  accountName: string;
}
export interface PayoutResult {
  status: "PROCESSING" | "PAID" | "FAILED";
  providerRef: string;
  reason?: string;
}

export interface PaymentProvider {
  createVirtualAccount(memberId: string, name: string): Promise<{ bankName: string; accountNumber: string; accountName: string }>;
  payout(req: PayoutRequest): Promise<PayoutResult>;
}

class MockProvider implements PaymentProvider {
  async createVirtualAccount(memberId: string, name: string) {
    const n = (Math.abs(hash(memberId)) % 9_000_000_000 + 1_000_000_000).toString();
    return { bankName: "Mock Bank", accountNumber: n, accountName: `Infinite Coop / ${name}` };
  }
  async payout(req: PayoutRequest): Promise<PayoutResult> {
    return { status: "PAID", providerRef: `MOCK-${req.reference}` };
  }
}

function hash(s: string) {
  let h = 0;
  for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) | 0;
  return h;
}

export function getPaymentProvider(): PaymentProvider {
  switch (process.env.PAYMENT_PROVIDER) {
    case "mock":
    default:
      return new MockProvider();
  }
}

export function verifyWebhookSignature(rawBody: string, signature: string | null): boolean {
  const secret = process.env.PAYMENT_WEBHOOK_SECRET;
  if (!secret || !signature) return false;
  const expected = createHmac("sha256", secret).update(rawBody).digest("hex");
  const a = Buffer.from(expected);
  const b = Buffer.from(signature);
  return a.length === b.length && timingSafeEqual(a, b);
}

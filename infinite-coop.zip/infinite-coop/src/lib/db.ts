import { PrismaClient } from "@prisma/client";

// Singleton: avoids exhausting connections during hot reload and serverless reuse.
const globalForPrisma = globalThis as unknown as { prisma?: PrismaClient };

export const db = globalForPrisma.prisma ?? new PrismaClient();

if (process.env.NODE_ENV !== "production") globalForPrisma.prisma = db;

# Technical Requirements Document (TRD)

## 1. Architecture overview
Modular monolith, deployable as one container, split into clear domain modules so services can be extracted later.

```
Browser (mobile-first) ──► Next.js (App Router, React, SSR/RSC)
                              │  Route handlers /api/*
                              ▼
                    Domain services (TypeScript/Node.js)
        auth · members/KYC · ledger · deposits · withdrawals · interest · loans · reports · audit
                              │
              ┌───────────────┼────────────────┐
              ▼               ▼                ▼
        PostgreSQL        Redis/queue      Provider adapters
        (Prisma)       (jobs, rate limit)  (payments, KYC, SMS/email)
```

## 2. Technology choices
| Concern | Choice | Reason |
|---|---|---|
| Frontend | Next.js 14+, React, Tailwind CSS | SSR for SEO on public pages, one codebase |
| Backend | Node.js route handlers + service layer | Same language end to end |
| Database | PostgreSQL 15+ | ACID, row locks, numeric types, full-text search |
| ORM | Prisma | Typed schema, migrations |
| Jobs | BullMQ + Redis (or pg-boss to avoid Redis) | Interest runs, reconciliation, notifications |
| Auth | Session cookies (httpOnly, SameSite), argon2id, TOTP for staff | Safer than long-lived JWT in localStorage |
| Validation | Zod | Shared schemas |
| Tests | Vitest, Playwright | Unit/e2e |
| Hosting | Docker on managed container platform + managed Postgres | Simple ops |
| C# | Optional: a separate reporting/reconciliation worker if the team prefers .NET; not required for MVP | Avoids needless polyglot complexity |

## 3. Financial integrity rules
1. **Double-entry ledger.** Every money event creates balanced entries (sum of debits = sum of credits) in one DB transaction.
2. **Append-only.** Ledger entries are never updated or deleted; corrections are reversing entries.
3. **Money as integers.** Store amounts in kobo (BigInt) — never floating point.
4. **Balances derived.** Member balance = sum of ledger lines on the member's liability account; a cached balance column may exist but is verified nightly.
5. **Concurrency.** Withdrawals take a `SELECT … FOR UPDATE` on the wallet row and re-check available balance inside the transaction.
6. **Idempotency.** Every external call and webhook carries a unique key stored with a unique index.
7. **Reconciliation.** Daily job matches provider settlement reports to ledger; unmatched items open exceptions for staff.
8. **Maker-checker.** The user who creates a withdrawal/disbursement cannot approve it.

### Chart of accounts (core)
- Assets: Bank – Collections, Bank – Payouts, Loans Receivable, Interest Receivable
- Liabilities: Member Savings (per-member sub-ledger), Pending Settlements
- Income: Loan Interest Income, Fees Income
- Expenses: Interest on Savings, Loan Loss Provision

## 4. Key algorithms
- **Savings interest:** daily accrual = closing balance × rate / 365 (kobo, banker's rounding at credit time); monthly credit posts Dr Interest Expense / Cr Member Savings.
- **Loan schedule:** reducing-balance amortisation with configurable frequency; flat option per policy.
- **Arrears:** nightly job marks overdue instalments, computes days past due, buckets (1–30, 31–60, 61–90, 90+).

## 5. API design (REST, JSON)
Auth: `POST /api/auth/register|login|logout|verify-otp`
Member: `GET /api/me`, `GET /api/wallet`, `GET /api/transactions`, `GET /api/statements`
Deposits: `POST /api/deposits/initiate`, `POST /api/webhooks/payments`
Withdrawals: `POST /api/withdrawals`, `GET /api/withdrawals/:id`
Loans: `POST /api/loans/apply`, `GET /api/loans`, `POST /api/loans/:id/accept`
Admin: `/api/admin/kyc`, `/admin/withdrawals`, `/admin/loans`, `/admin/reconciliation`, `/admin/settings`, `/admin/audit`
Errors use RFC 7807 problem+json. All mutating routes require CSRF protection and idempotency keys where money is involved.

## 6. Security requirements
- TLS everywhere; HSTS; strict CSP.
- Passwords: argon2id; account lockout and rate limiting.
- MFA mandatory for all staff; role-based access control with least privilege.
- PII encryption at column level for BVN/NIN; secrets in a vault/environment manager.
- Webhook signature verification (HMAC) and IP allow-list.
- Audit log: who, what, before/after, IP, timestamp; tamper-evident (hash chain).
- Dependency scanning, SAST in CI, annual penetration test.
- NDPA compliance: consent, retention schedule, data-subject requests.

## 7. Performance, search and memory management
- Indexes on `(memberId, createdAt)`, `membershipNumber`, `reference`, `status`.
- PostgreSQL full-text (`tsvector`) / trigram indexes for member and transaction search in admin.
- Keyset pagination for transaction history (no deep OFFSET).
- Stream large statements/exports (Node streams) rather than loading into memory.
- Prisma client singleton to avoid connection exhaustion; PgBouncer for pooling.
- Batch jobs process members in chunks of 500 with cursor iteration.
- Public pages statically generated/ISR; semantic HTML, sitemap, structured data for search engines.

## 8. Environments and DevOps
Dev, staging, production. GitHub Actions: lint, typecheck, test, build image, deploy. Infrastructure as code. Daily encrypted backups, 30-day retention, quarterly restore drills. Observability: structured logs, error tracking, uptime and queue-depth alerts.

## 9. Integrations
- Payment/banking partner: virtual accounts, webhooks, payout API (adapter interface; swap providers without core changes).
- KYC provider: BVN/NIN, liveness, document check.
- Messaging: email (SMTP/API), SMS.

## 10. Testing strategy
Unit tests for ledger, interest and amortisation (property tests: ledger always balances); integration tests with a real Postgres; e2e flows for registration → deposit → withdraw; concurrency test for double-withdrawal; webhook replay test; reconciliation test.

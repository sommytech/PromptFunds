# Implementation Plan

## 0. Gate before any member funds are accepted
Obtain written regulatory/legal confirmation covering: accepting savings, paying interest, and paying withdrawals to member bank accounts, given the cooperative's current licence scope (lending, no transaction services). If the position is "loans only", launch Phase 2 first and treat savings as a later phase or route funds through a licensed partner.

## 1. Timeline (≈ 20 weeks)

| Weeks | Phase | Key outputs |
|---|---|---|
| 1–3 | Discovery & design | Signed PRD, policies draft, UX prototype, partner selection |
| 4–11 | Phase 1: Core MVP | Registration, KYC, ledger, wallet, deposits, withdrawals, interest, admin, public site |
| 12–17 | Phase 2: Lending | Applications, approvals, disbursement, schedules, repayments, arrears |
| 18–20 | Phase 3: Hardening | Reports, pen test, load test, UAT, go-live checklist |
| 21+ | Pilot & scale | Soft launch with 50–100 members, then open registration |

## 2. Sprint plan (2-week sprints)
1. **S1–S2** Auth, RBAC, audit log, project scaffold, CI/CD, staging.
2. **S3** KYC integration, admin KYC queue, membership numbers.
3. **S4** Ledger core, chart of accounts, wallet views.
4. **S5** Deposits, webhooks, reconciliation job.
5. **S6** Withdrawals with maker-checker, payouts, liquidity view.
6. **S7** Interest accrual/credit, statements, notifications.
7. **S8–S9** Loan products, application, assessment, approvals.
8. **S10** Disbursement, schedules, repayments, arrears.
9. **S11** Reports, exports, security fixes.
10. **S12** UAT, performance tuning, go-live.

## 3. Team
Product owner (cooperative), project manager, 2 full-stack engineers, 1 backend/fintech engineer, 1 UI/UX designer (part-time), 1 QA, 1 DevOps (part-time), external accountant reviewer.

## 4. Governance and policies to approve (parallel track)
Savings policy and interest rate, withdrawal limits and SLA, liquidity reserve ratio, loan eligibility, pricing and provisioning policy, KYC/AML policy, data protection policy, incident response plan.

## 5. Testing and acceptance
- Ledger invariants: trial balance is zero after every test scenario.
- Concurrency test: parallel withdrawals never exceed balance.
- Webhook replay and out-of-order tests.
- Interest recalculation matches an independent spreadsheet.
- Pen test with no open critical/high findings.
- UAT with cooperative staff and a pilot member group; signed acceptance.

## 6. Go-live checklist
- [ ] Regulatory sign-off on file
- [ ] Bank/payment accounts live and tested with small real amounts
- [ ] Production secrets rotated, backups and restore verified
- [ ] Monitoring and on-call rota active
- [ ] Support process, FAQs and complaint handling ready
- [ ] Opening ledger balanced and reviewed by accountant

## 7. Risks and mitigations
| Risk | Mitigation |
|---|---|
| Regulatory scope unclear | Legal opinion before launch; feature flags to disable savings |
| Liquidity shortfall | Reserve ratio, withdrawal limits, daily liquidity report |
| Reconciliation errors | Automated matching, exception queue, daily review |
| Fraud / account takeover | MFA for staff, re-auth for withdrawals, name-match on payouts |
| Loan defaults | Conservative limits, savings-linked eligibility, provisioning |
| Scope creep | Phase gating; change control board |
| Vendor lock-in | Provider adapter interfaces |

## 8. Post-launch
Weekly KPI review (registrations, KYC pass rate, deposit success, withdrawal SLA, PAR30), monthly financial review, quarterly security review, evaluate native app and USSD at 5,000 active members.

## 9. Deploying the included package
See `README.md` in the repository root: set environment variables, run `docker compose up`, run `prisma migrate deploy` and `prisma db seed`, then configure the payment webhook URL.

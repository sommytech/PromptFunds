# App Flow

## 1. Sitemap
**Public:** `/` · `/about` · `/membership` · `/savings` · `/loans` · `/faq` · `/register` · `/login`
**Member:** `/dashboard` · `/wallet` · `/deposit` · `/withdraw` · `/transactions` · `/statements` · `/loans` · `/loans/apply` · `/loans/[id]` · `/profile` · `/notifications`
**Admin:** `/admin` · `/admin/kyc` · `/admin/members` · `/admin/transactions` · `/admin/reconciliation` · `/admin/withdrawals` · `/admin/loans` · `/admin/liquidity` · `/admin/reports` · `/admin/settings` · `/admin/audit`

## 2. Registration and KYC
```mermaid
flowchart TD
  A[Visit /register] --> B[Enter name, phone, email, password]
  B --> C[Verify OTP]
  C --> D[Submit BVN/NIN + selfie/ID]
  D --> E{Automated check}
  E -- pass --> F[KYC officer review]
  E -- fail --> G[Request resubmission]
  G --> D
  F -- approve --> H[Membership number issued, dashboard unlocked]
  F -- reject --> I[Notify with reason]
```

## 3. Deposit
```mermaid
flowchart TD
  A[Member opens Deposit] --> B[Sees personal virtual account / pays via gateway]
  B --> C[Transfer made]
  C --> D[Provider webhook received]
  D --> E{Signature valid and not duplicate?}
  E -- no --> X[Reject and log]
  E -- yes --> F[Record PENDING transaction]
  F --> G[Reconciliation match]
  G -- matched --> H[Post ledger entries, balance updates, notify]
  G -- unmatched --> I[Exception queue for finance officer]
```

## 4. Withdrawal
```mermaid
flowchart TD
  A[Member requests withdrawal] --> B{Amount ≤ available balance?}
  B -- no --> X[Reject with message]
  B -- yes --> C[Place hold, status PENDING_APPROVAL]
  C --> D[Finance officer reviews: liquidity + limits]
  D --> E{Checker approves? different user}
  E -- no --> F[Release hold, notify member]
  E -- yes --> G[Payout to verified account via partner]
  G --> H{Provider confirms?}
  H -- yes --> I[Post ledger, status PAID, notify]
  H -- no --> J[Retry / reverse hold, alert]
```

## 5. Interest
Daily job accrues interest per member → month-end job credits accrued interest as ledger entries → notification and statement line.

## 6. Loan lifecycle (Phase 2)
```mermaid
flowchart TD
  A[Member applies: amount, tenor, purpose] --> B[System pre-checks eligibility]
  B --> C[Loan officer assesses affordability and savings history]
  C --> D[Committee decision]
  D -- decline --> E[Notify with reason]
  D -- approve --> F[Offer with schedule shown]
  F --> G[Member accepts digitally]
  G --> H[Finance disburses; recorded in ledger]
  H --> I[Repayments: wallet auto-debit or deposit-then-pay]
  I --> J{Overdue?}
  J -- yes --> K[Arrears reminders, escalation]
  J -- no --> L[Loan closed when settled]
```

## 7. Admin approval routing
| Action | Maker | Checker |
|---|---|---|
| KYC approval | KYC Officer | — (audit logged) |
| Withdrawal | Finance Officer | Finance Approver |
| Loan approval | Loan Officer | Committee |
| Loan disbursement | Finance Officer | Finance Approver |
| Rate or policy change | Admin | Second Admin |

## 8. Notification triggers
Registration OTP, KYC result, deposit received, withdrawal requested/approved/paid/rejected, interest credited, loan decision, repayment due, repayment received, overdue notice.

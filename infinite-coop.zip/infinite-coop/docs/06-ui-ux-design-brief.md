# UI/UX Design Brief

## 1. Design principles
1. **Trust first:** calm, clear, financial-grade; show exactly where numbers come from.
2. **Mobile first:** design at 360px, scale up; thumb-friendly primary actions.
3. **Plain language:** no jargon; every term (available vs total balance) explained inline.
4. **Low bandwidth:** light pages, no heavy imagery, skeleton loaders, works on 3G.
5. **Inclusive:** WCAG 2.1 AA, large tap targets (≥48px), good contrast, support for English first, with room for Pidgin/Yoruba/Igbo/Hausa later.

## 2. Brand direction
- Personality: dependable, warm, community-owned.
- Palette: deep green (primary, growth/trust), warm gold (accent), off-white background, slate text; red/amber/green only for status.
- Type: a clean humanist sans (e.g. Inter or Source Sans 3), tabular numerals for amounts.
- Shape: rounded 12px cards, generous spacing, subtle shadows.
- Amounts always formatted `₦1,250,000.00`.

## 3. Key screens

**Landing page** — Hero ("Save. Grow. Borrow. Free to join."), three benefit cards, savings and loan product summaries with example interest, how-it-works in 4 steps, FAQ accordion, sticky "Join free" button.

**Register / KYC** — Short multi-step form with progress bar (Account → Verify phone → Identity → Done). One question per screen on mobile. Camera capture for selfie. Clear statement of why data is needed.

**Dashboard** — Top: greeting + membership number. Hero card: total balance with eye-toggle to hide. Row of stat chips: Available, Interest earned, Pending. Primary buttons: **Deposit**, **Withdraw**, **Apply for loan**. Below: loan summary with next instalment and due date; recent transactions (5); notices.

**Deposit** — Shows the member's personal account number and bank with copy button, plus "Pay with card/bank" option; live status of the latest deposit; note on how long confirmation takes.

**Withdraw** — Amount input with available balance shown, destination account (locked to verified account), expected timeline, confirmation sheet, then status tracker (Requested → Approved → Paid).

**Transactions** — Filter chips (All, Deposits, Withdrawals, Interest, Loans), search, grouped by date, status badges, infinite scroll, tap for receipt.

**Statements** — Date range picker, download PDF/CSV.

**Loans** — Products with calculator (amount, tenor → instalment, total cost shown transparently); application wizard; loan detail page with schedule timeline and repay button.

**Admin** — Dense, desktop-first tables with filters, saved views, keyboard navigation; KYC side-by-side document review; reconciliation split view (provider vs ledger); liquidity gauge showing cash vs withdrawals due; approvals inbox with SLA timers.

## 4. Components
Button (primary/secondary/ghost), amount input, OTP input, stat card, status badge, data table, stepper, toast, bottom sheet (mobile), modal (desktop), empty state, skeleton, file/camera uploader.

## 5. States to design
Loading, empty, error, offline, pending, success, rejected, session timeout, maintenance, and "KYC pending" lock screen.

## 6. Security UX
Auto-logout after inactivity with warning; re-authenticate (password/OTP) before withdrawals; masked account numbers; clear confirmation of destination account before payout; staff MFA prompts.

## 7. SEO and content (public pages)
Semantic headings, meta titles/descriptions, Open Graph, FAQ schema markup, sitemap, fast Core Web Vitals, accessible alt text.

## 8. Deliverables
Wireframes → high-fidelity mockups (mobile + desktop) → clickable prototype → design tokens and component library handed off in Figma → usability test with 5–8 target members before build lock.

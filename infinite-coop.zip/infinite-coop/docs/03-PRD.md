# Product Requirements Document (PRD)

**Product:** Infinite Cooperative digital savings and lending platform
**Version:** 1.0 · **Status:** Draft for approval

## 1. Purpose
Let members register free, save, earn interest, withdraw eligible savings and borrow, entirely online. The cooperative holds a licence for lending, not for transactions, so the platform **must not** offer member-to-member or interbank transfers.

## 2. Goals and success metrics
- Registration to approval under 24 hours (KYC pass rate > 85%).
- 100% of displayed balances reconcile to the ledger and bank records daily.
- Withdrawal processing within the published SLA (target 1 business day).
- Loan decision within 3 business days; arrears (PAR30) under 8%.
- Mobile-usable: all flows work on a 360px-wide phone on 3G.

## 3. Users and roles
| Role | Description |
|---|---|
| Visitor | Browses the public site |
| Member | Verified user with wallet and loan access |
| KYC Officer | Reviews identity submissions |
| Finance Officer | Reconciles deposits, processes withdrawals (maker) |
| Finance Approver | Approves withdrawals/disbursements (checker) |
| Loan Officer / Committee | Assesses and approves loans |
| Admin | Configures products, rates, users and roles |
| Auditor | Read-only access to ledgers and audit trail |

## 4. Scope

### 4.1 Launch (MVP)
**Registration and KYC** — Free sign-up with email/phone OTP; unique membership number (format `IC-YYYY-NNNNNN`); electronic identity verification (BVN/NIN plus selfie/ID upload); admin approval; dashboard access only after approval. No minimum deposit or monthly contribution.

**Savings wallet** — Shows total balance, available balance, total deposits, total withdrawals, interest earned, transaction history, pending transactions, loan balances and repayment obligations. Balances are derived from the ledger, never stored as editable numbers.

**Deposits** — Any amount, through supported bank transfer (virtual account per member) or approved gateway. Credited only after confirmation and reconciliation; duplicates are rejected by idempotency keys.

**Withdrawals** — Member requests; system checks available balance (excluding holds, loan collateral/lien rules); request recorded; maker-checker authorisation; payout to the member's single verified bank account only (name-match check). Published processing timelines; liquidity check before approval.

**Interest on savings** — Rate set by Admin per savings policy; daily accrual on eligible balance, credited monthly; calculation method and rate shown to members; every credit is a ledger entry.

**Notifications** — Email/SMS for deposits, withdrawals, interest, loan events.

**Admin portal** — KYC queue, transaction monitoring, reconciliation, withdrawal approvals, liquidity dashboard, audit trail, basic reports.

**Public website** — About, benefits, savings and loan products, FAQs, registration.

### 4.2 Phase 2
Loan applications, affordability assessment, committee approval, disbursement recording, repayment schedules (reducing balance or flat per policy), auto-debit from wallet where member consents, arrears monitoring and reminders, loan statements.

### 4.3 Later
Native apps, USSD/WhatsApp, guarantor workflow, group savings, investment module, advanced credit scoring, accounting-system integration.

## 5. Out of scope and hard constraints
- No wallet-to-wallet transfers, no transfers to third parties, no bill payments, no card issuing.
- Payouts only to the member's own verified account.
- No balance display that is not supported by ledger entries.

## 6. Functional requirements (selected, testable)
| ID | Requirement |
|---|---|
| FR-01 | Registration is free and requires no payment. |
| FR-02 | Each approved member receives a unique, immutable membership number. |
| FR-03 | Member cannot access wallet until KYC status = APPROVED. |
| FR-04 | A deposit credits the wallet only after provider confirmation and reconciliation. |
| FR-05 | Webhook processing is idempotent; replays create no duplicate entries. |
| FR-06 | Withdrawal amount ≤ available balance at request and at approval. |
| FR-07 | Withdrawals above a configurable limit require a second approver. |
| FR-08 | Payout destination must match the verified account holder name. |
| FR-09 | Interest = daily balance × annual rate ÷ 365, credited monthly, posted as ledger entries. |
| FR-10 | Every admin action on money, members or settings is written to the audit log. |
| FR-11 | Statements exportable as PDF/CSV for any date range. |
| FR-12 | Loan repayment schedule is generated at approval and shown before the member accepts. |

## 7. Non-functional requirements
Security (MFA for staff, encryption in transit/at rest, rate limiting), availability 99.5%, p95 page response < 2s, accessibility WCAG 2.1 AA, data protection compliance (NDPR/NDPA), full audit trail, daily backups with tested restore.

## 8. Dependencies and open decisions
1. Regulatory confirmation that accepting member savings and paying them out is permitted under the cooperative's registration and licence.
2. Choice of banking/payment partner and KYC provider.
3. Approved savings rate, loan pricing, withdrawal limits and SLAs.
4. Liquidity reserve policy.

## 9. Release criteria
All FRs pass UAT; reconciliation tests balance to zero; penetration test findings resolved; policies signed off; regulator position documented.

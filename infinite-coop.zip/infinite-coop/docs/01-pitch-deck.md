# Infinite Cooperative — Pitch Deck

*(One section per slide. Paste into Slides, or ask for a styled deck.)*

## Slide 1 — Title
**Infinite Cooperative**
Free-to-join digital savings and lending for every member, from any phone.

## Slide 2 — The problem
- Millions of workers and small traders have no affordable, trustworthy place to save.
- Credit is slow, paper-based and expensive; branch visits cost time and money.
- Existing cooperatives run on spreadsheets and handwritten ledgers, so balances are hard to trust.

## Slide 3 — Our solution
A mobile-first web platform where a member can:
1. Register free and get verified electronically.
2. Deposit any amount through approved channels.
3. See a live, ledger-backed balance and interest earned.
4. Request withdrawals of eligible savings.
5. Apply for a loan without visiting an office.

## Slide 4 — How it works
Register → Verify (KYC) → Deposit → Earn interest → Borrow → Repay.
Every naira shown on screen is backed by a double-entry ledger reconciled to bank records.

## Slide 5 — Product
- Public website: about, savings and loan products, FAQs, registration.
- Member portal: wallet, statements, loan applications and repayments.
- Admin portal: KYC review, approvals, reconciliation, liquidity, audit trail.

## Slide 6 — Why members will join
- Zero cost to register, no minimum deposit, no compulsory monthly contribution.
- Transparent interest and loan pricing shown before commitment.
- Works on any smartphone browser; no app download needed.

## Slide 7 — Business model
Income: loan interest, permitted investment income, other authorised cooperative income.
Costs: interest on savings, technology, payment processing, administration, expected loan losses.
Surplus after provisions and reserves is applied per cooperative rules and law.

## Slide 8 — Compliance-first design
- Loans and savings only; **no member-to-member or interbank transfers**.
- Withdrawals are admin-authorised payouts to the member's own verified account.
- Immutable ledger, audit trails, role-based approvals, maker-checker on money movement.

## Slide 9 — Roadmap
- Phase 1 (MVP): registration, KYC, wallet, deposits, withdrawals, interest, admin.
- Phase 2: digital lending, arrears tracking, reports.
- Phase 3: notifications, USSD/WhatsApp, native apps when volume justifies.

## Slide 10 — Go-to-market
Employer and community partnerships, existing cooperative groups, referral by member number, agent-assisted onboarding.

## Slide 11 — Risk and controls
Liquidity buffer policy, loan-loss provisioning, reconciliation before crediting, fraud and AML screening, regulator sign-off before taking funds.

## Slide 12 — The ask
Approve the MVP build, confirm the regulatory position, select the banking and payment partner, and appoint the loan committee.

# Implementation Cost Proposal

**Currency:** Nigerian Naira (NGN), indicative estimates for planning only. Obtain at least two vendor quotes before committing. Figures assume a small team in Nigeria and a 20-week build.

## 1. Assumptions
- Web-first, mobile-responsive; no native apps in Phase 1–2.
- Stack: Next.js, Node.js, PostgreSQL, Prisma, cloud hosting.
- One payment/banking partner for deposits and payouts, one KYC provider.
- Day rates are blended averages and will vary by vendor.

## 2. One-off build costs

| Phase | Scope | Duration | Est. cost (NGN) |
|---|---|---|---|
| 0. Discovery & design | Requirements sign-off, UI/UX, clickable prototype | 3 weeks | 3,500,000 |
| 1. Core MVP | Registration, KYC, wallet ledger, deposits, withdrawals, interest, admin basics | 8 weeks | 14,000,000 |
| 2. Lending | Applications, scoring inputs, approvals, disbursement records, schedules, repayments, arrears | 6 weeks | 9,500,000 |
| 3. Reporting & hardening | Financial reports, audit exports, security testing, load testing | 3 weeks | 4,000,000 |
| QA & UAT | Test plans, financial-control testing, UAT support | across phases | 3,000,000 |
| Project management | Delivery lead, ceremonies, documentation | across phases | 3,000,000 |
| **Subtotal** | | **~20 weeks** | **37,000,000** |
| Contingency (15%) | | | 5,550,000 |
| **Total build** | | | **42,550,000** |

## 3. Recurring annual costs

| Item | Est. annual (NGN) |
|---|---|
| Cloud hosting (app, managed Postgres, backups, staging) | 2,400,000 |
| KYC / BVN-NIN verification (per check, ~2,000 members/yr) | 1,000,000 |
| SMS / email / WhatsApp notifications | 1,200,000 |
| Payment gateway fees (pass-through, volume-based) | variable (typ. 1–1.5% per deposit) |
| Monitoring, logging, error tracking | 600,000 |
| Security testing and annual penetration test | 2,500,000 |
| Maintenance & support retainer (15–20% of build) | 7,000,000 |
| **Total recurring (excl. gateway fees)** | **~14,700,000** |

## 4. Pre-launch non-technical costs (not included above)
- Legal and regulatory advisory, cooperative bylaws and policy documents.
- Bank account setup and escrow/trust arrangements.
- External accountant for ledger design review.
- Marketing and member onboarding.

## 5. Options to control cost
1. **Phase 1 only first** (~NGN 20.5m incl. design, contingency) and launch savings before lending.
2. Use a managed identity provider and hosted payment pages to reduce custom security work.
3. Defer native apps, USSD and WhatsApp until member volume justifies them.
4. Use open-source components (Next.js, Prisma, PostgreSQL) to avoid licences.

## 6. Break-even sketch
Annual run cost ≈ NGN 14.7m + interest paid on savings. Income must come from loan interest, permitted investments and other authorised income. Example: a loan book of NGN 150m at 20% p.a. gross yields NGN 30m before provisions and savings interest, so the platform pays for itself at moderate scale, provided loan losses stay controlled and liquidity is maintained.

## 7. Payment terms (suggested)
20% on signing, 20% on design approval, 30% on MVP acceptance, 20% on lending acceptance, 10% after 30 days of production stability.

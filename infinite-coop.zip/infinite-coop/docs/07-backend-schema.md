# Backend Schema

The authoritative schema is `prisma/schema.prisma` in this repository. This page explains the design.

## 1. Design rules
- PostgreSQL, Prisma ORM, all primary keys `cuid`.
- **Money is `BigInt` kobo.** No floats or decimals in application code.
- **Ledger is append-only** (`LedgerEntry` + `LedgerLine`). Mistakes are fixed with reversing entries (`reversalOfId`).
- `Wallet` holds cached balances and holds for fast reads. A nightly job recomputes from the ledger and alerts on any difference.
- `AuditLog` is hash-chained (`prevHash` → `hash`) so tampering is detectable.

## 2. Entity groups

| Group | Tables |
|---|---|
| Identity & access | `User`, `Session`, `OtpCode` |
| Membership & KYC | `Member`, `KycDocument`, `BankAccount`, `VirtualAccount`, `MembershipCounter` |
| Ledger | `LedgerAccount`, `LedgerEntry`, `LedgerLine` |
| Savings | `Wallet`, `Transaction`, `Deposit`, `Withdrawal`, `InterestPolicy`, `InterestAccrual` |
| Lending | `LoanProduct`, `Loan`, `LoanInstalment`, `LoanRepayment` |
| Operations | `ReconciliationRun`, `ReconciliationItem`, `Notification`, `Setting`, `AuditLog` |

## 3. Relationships (summary)
- `User 1—1 Member 1—1 Wallet 1—1 LedgerAccount (member liability)`
- `Member 1—1 BankAccount` (single payout destination), `Member 1—1 VirtualAccount`
- `Member 1—n Deposit | Withdrawal | Loan | Transaction`
- `LedgerEntry 1—n LedgerLine`; each entry must satisfy Σdebit = Σcredit (enforced in service layer and by a deferred constraint trigger in `prisma/sql/ledger_constraints.sql`)
- `Loan 1—n LoanInstalment | LoanRepayment`; `Loan n—1 LoanProduct`

## 4. Posting examples (amounts in kobo)

| Event | Debit | Credit |
|---|---|---|
| Deposit confirmed ₦10,000 | Bank – Collections | Member Savings (member) |
| Withdrawal paid ₦4,000 | Member Savings (member) | Bank – Payouts |
| Monthly interest ₦150 | Interest on Savings (expense) | Member Savings (member) |
| Loan disbursed ₦100,000 | Loans Receivable | Bank – Payouts |
| Loan repayment (principal 8,000 / interest 1,500) | Bank – Collections | Loans Receivable 8,000 · Loan Interest Income 1,500 |

## 5. Search and performance
- `Member.searchText` (lowercased name, number, phone) with a trigram GIN index added in `prisma/sql/search_indexes.sql` for fast admin search.
- Composite indexes: `Transaction(memberId, createdAt desc)`, `Deposit(memberId, createdAt)`, `LoanInstalment(dueDate, status)`.
- Unique indexes enforce idempotency: `LedgerEntry.idempotencyKey`, `Deposit.providerReference`, `Withdrawal.idempotencyKey`, `Transaction.reference`.
- Keyset pagination on `(createdAt, id)` for transaction history.

## 6. Integrity checks (run nightly)
1. Trial balance: Σdebits = Σcredits across the ledger.
2. Per member: `Wallet.balanceKobo` = Σ(credit − debit) on member's ledger account.
3. Σ member savings accounts ≤ bank collections balance reconciled to provider statements.
4. No negative available balance: `balanceKobo − heldKobo ≥ 0`.

## 7. Retention
Ledger, audit and KYC records retained per regulatory schedule (minimum 6 years assumed; confirm with legal). Personal data deletion requests handled by anonymising non-ledger fields.

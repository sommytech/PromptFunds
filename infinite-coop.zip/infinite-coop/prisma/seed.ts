import { PrismaClient } from "@prisma/client";
import argon2 from "argon2";

const db = new PrismaClient();

async function main() {
  const accounts = [
    { code: "1000-BANK-COLL", name: "Bank – Collections", type: "ASSET" },
    { code: "1010-BANK-PAYOUT", name: "Bank – Payouts", type: "ASSET" },
    { code: "1200-LOANS-REC", name: "Loans Receivable", type: "ASSET" },
    { code: "4000-LOAN-INT", name: "Loan Interest Income", type: "INCOME" },
    { code: "5000-INT-SAVINGS", name: "Interest on Savings", type: "EXPENSE" },
    { code: "5100-LOSS-PROV", name: "Loan Loss Provision", type: "EXPENSE" },
  ] as const;
  for (const a of accounts) await db.ledgerAccount.upsert({ where: { code: a.code }, update: {}, create: a });

  const adminPassword = process.env.SEED_ADMIN_PASSWORD ?? "ChangeMe-Now-12345";
  const staff = [
    { email: "admin@infinitecoop.local", phone: "2348000000001", role: "ADMIN" },
    { email: "kyc@infinitecoop.local", phone: "2348000000002", role: "KYC_OFFICER" },
    { email: "finance@infinitecoop.local", phone: "2348000000003", role: "FINANCE_OFFICER" },
    { email: "approver@infinitecoop.local", phone: "2348000000004", role: "FINANCE_APPROVER" },
  ] as const;
  const passwordHash = await argon2.hash(adminPassword, { type: argon2.argon2id });
  for (const s of staff) {
    await db.user.upsert({ where: { email: s.email }, update: {}, create: { ...s, passwordHash, status: "ACTIVE" } });
  }

  const hasPolicy = await db.interestPolicy.count();
  if (!hasPolicy) await db.interestPolicy.create({ data: { annualRateBps: 600, dayCount: 365, effectiveFrom: new Date("2026-01-01") } }); // 6.00% placeholder — set by approved policy

  const hasProduct = await db.loanProduct.count();
  if (!hasProduct)
    await db.loanProduct.create({
      data: { name: "Member Starter Loan", minAmountKobo: 5_000_000n, maxAmountKobo: 100_000_000n, minTenorMonths: 3, maxTenorMonths: 12, annualRateBps: 2400 },
    });

  console.log("Seed complete. Change the staff passwords immediately and enable MFA.");
}

main().finally(() => db.$disconnect());

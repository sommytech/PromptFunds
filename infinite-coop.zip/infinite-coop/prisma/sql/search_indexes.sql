-- Fast admin member search (name, phone, membership number).
CREATE EXTENSION IF NOT EXISTS pg_trgm;
CREATE INDEX IF NOT EXISTS member_search_trgm ON "Member" USING gin ("searchText" gin_trgm_ops);
CREATE INDEX IF NOT EXISTS transaction_ref_trgm ON "Transaction" USING gin ("reference" gin_trgm_ops);
